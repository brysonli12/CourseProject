# Clip 'n Search  Chrome Extension
Credit goes to CS 410 TAs for originally developing this extension
  (and I took the relevant parts and slightly modified/extended it
  [made a simple version for this final project], the server is something I did by myself).
 Additional credits on github/about section of website.
